<?php
if (isset($_GET['v'])) {
    $archivo = basename($_GET['v']); // Evita navegación por directorios
    $rutaAbsoluta = "/usr/bin/.videos/" . $archivo;

    if (!empty($archivo) && file_exists($rutaAbsoluta)) {
        $size = filesize($rutaAbsoluta);
        $file = fopen($rutaAbsoluta, 'rb');
        
        $start = 0;
        $end = $size - 1;
        $length = $size;

        header('Content-Type: video/mp4');
        header('Accept-Ranges: bytes');

        if (isset($_SERVER['HTTP_RANGE'])) {
            $c_start = $start;
            $c_end = $end;

            list(, $range) = explode('=', $_SERVER['HTTP_RANGE'], 2);
            if (strpos($range, ',') !== false) {
                header('HTTP/1.1 416 Requested Range Not Satisfiable');
                header("Content-Range: bytes $start-$end/$size");
                exit;
            }
            if ($range == '-') {
                $c_start = $size - substr($range, 1);
            } else {
                $range = explode('-', $range);
                $c_start = $range[0];
                $c_end = (isset($range[1]) && is_numeric($range[1])) ? $range[1] : $size - 1;
            }
            $c_end = ($c_end > $end) ? $end : $c_end;
            if ($c_start > $c_end || $c_start > $size - 1 || $c_end >= $size) {
                header('HTTP/1.1 416 Requested Range Not Satisfiable');
                header("Content-Range: bytes $start-$end/$size");
                exit;
            }
            $start = $c_start;
            $end = $c_end;
            $length = $end - $start + 1;
            fseek($file, $start);
            header('HTTP/1.1 206 Partial Content');
            header("Content-Range: bytes $start-$end/$size");
        } else {
            header("Content-Range: bytes 0-$end/$size");
        }

        header("Content-Length: " . $length);

        $buffer = 8192;
        while (!feof($file) && ($p = ftell($file)) <= $end) {
            if ($p + $buffer > $end) {
                $buffer = $end - $p + 1;
            }
            set_time_limit(0);
            echo fread($file, $buffer);
            flush();
        }
        fclose($file);
        exit;
    } else {
        http_response_code(404);
        echo "Video MP4 no encontrado";
        exit;
    }
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$host = '127.0.0.1'; $db = 'ca_jueves'; $user = 'computacion'; $pass = 'aplicada';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
    $stmt = $pdo->query('SELECT banda, tema, archivo_mp4, youtube_id FROM videos ORDER BY id ASC');
    $videos = $stmt->fetchAll();
} catch (\PDOException $e) {
    die("Error de conexión a la base de datos: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Playlist CA Jueves</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #121212; color: #fff; padding: 20px; margin: 0; }
        h1 { text-align: center; margin-bottom: 15px; }
        .controls { text-align: center; margin-bottom: 30px; }
        .btn-play-all { background: #ff4757; color: #fff; border: none; padding: 12px 28px; font-size: 16px; font-weight: bold; border-radius: 30px; cursor: pointer; transition: background 0.2s, transform 0.2s; box-shadow: 0 4px 10px rgba(255, 71, 87, 0.4); }
        .btn-play-all:hover { background: #ff6b81; transform: scale(1.05); }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 25px; max-width: 1200px; margin: 0 auto; }
        .card { background: #1e1e1e; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
        .video-container { position: relative; padding-bottom: 56.25%; height: 0; background: #000; cursor: pointer; }
        .video-container img, .video-container video { position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; }
        .play-btn { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 60px; height: 60px; background: rgba(255, 0, 0, 0.85); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 22px; transition: transform 0.2s, background-color 0.2s; }
        .card:hover .play-btn { transform: translate(-50%, -50%) scale(1.1); background: rgba(255, 0, 0, 1); }
        .card-content { padding: 15px; }
        .banda { font-weight: bold; color: #ff4757; margin-bottom: 5px; }
    </style>
</head>
<body>

    <h1>Playlist CA Jueves</h1>
    
    <div class="controls">
        <button class="btn-play-all" onclick="reproducirTodo()">▶ Reproducir Todo</button>
    </div>

    <div class="grid">
        <?php foreach ($videos as $i => $video): ?>
            <?php 
                $banda = htmlspecialchars($video['banda'], ENT_QUOTES, 'UTF-8');
                $tema = htmlspecialchars($video['tema'], ENT_QUOTES, 'UTF-8');
                $mp4 = htmlspecialchars($video['archivo_mp4'], ENT_QUOTES, 'UTF-8');
                $ytId = htmlspecialchars($video['youtube_id'], ENT_QUOTES, 'UTF-8');
                $thumbMax = "https://img.youtube.com/vi/{$ytId}/maxresdefault.jpg";
                $thumbHq = "https://img.youtube.com/vi/{$ytId}/hqdefault.jpg";
            ?>
            <div class="card">
                <div class="video-container" id="video-box-<?= $i ?>" data-index="<?= $i ?>" data-yt="<?= $ytId ?>" data-mp4="<?= urlencode($mp4) ?>" onclick="reproducirIndex(<?= $i ?>)">
                    <img src="<?= $thumbMax ?>" onerror="this.onerror=null; this.src='<?= $thumbHq ?>';" alt="<?= $banda ?> - <?= $tema ?>">
                    <div class="play-btn">▶</div>
                </div>
                <div class="card-content">
                    <div class="banda"><?= $banda ?></div>
                    <div><?= $tema ?></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        const totalVideos = <?= count($videos) ?>;
        let indiceActual = -1;

        function restaurarPortadas() {
            const contenedores = document.querySelectorAll('.video-container');
            contenedores.forEach(c => {
                const ytId = c.dataset.yt;
                const thumbMax = `https://img.youtube.com/vi/${ytId}/maxresdefault.jpg`;
                const thumbHq = `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`;
                c.innerHTML = `
                    <img src="${thumbMax}" onerror="this.onerror=null; this.src='${thumbHq}';" alt="">
                    <div class="play-btn">▶</div>
                `;
            });
        }

        function reproducirIndex(index) {
            if (index < 0 || index >= totalVideos) return;
            
            restaurarPortadas();
            indiceActual = index;

            const contenedor = document.getElementById(`video-box-${index}`);
            const archivoMp4 = contenedor.dataset.mp4;

            contenedor.closest('.card').scrollIntoView({ behavior: 'smooth', block: 'center' });

            contenedor.innerHTML = `
                <video id="player-activo" src="index.php?v=${archivoMp4}" controls autoplay style="width:100%; height:100%; object-fit:contain;"></video>
            `;

            const video = document.getElementById('player-activo');
            video.onended = function() {
                if (indiceActual + 1 < totalVideos) {
                    reproducirIndex(indiceActual + 1);
                }
            };
        }

        function reproducirTodo() {
            reproducirIndex(0);
        }
    </script>

</body>
</html>

