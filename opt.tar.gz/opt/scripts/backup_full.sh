#!/bin/bash

# Mostrar ayuda
if [ "$1" = "-help" ] || [ "$1" = "help" ]; then
	echo "Uso: $0 origen destino"
	echo "Ejemplo: $0 /var/log /backup_dir"
	echo "Ejemplo: $0 /www_dir /backup_dir"
	exit 0
fi

#Validar cantidad de argumentos
if [ $# -ne 2 ]; then
	echo "Error: se deben ingresar dos argumentos (origen y destino)."
	exit 1
fi

#Validar directorio de origen
if [ ! -d "$1" ]; then
	echo "No existe el directorio de origen."
	exit 1
fi

#Validar que el origen este montado
if [ "$1" = "/www_dir" ] && ! mountpoint -q "$1"; then
	echo "El directorio /www_dir no esta disponible."
	exit 1
fi

#Validar directorio de destino
if [ ! -d "$2" ] || ! mountpoint -q "$2"; then
	echo "El directorio de destino no esta montado."
	exit 1
fi


#Obtener fecha
FECHA=$(date +%Y%m%d)

#Crear nombre del backup
BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz

#Crear backup
tar -czf "$2/$BACKUP" -C "$1" .

#Verificar resultado
if [ $? -eq 0 ]; then
	echo "Backup realizado correctamente: $2/$BACKUP"
else
	echo "Error al realizar el backup."
	exit 1
fi
